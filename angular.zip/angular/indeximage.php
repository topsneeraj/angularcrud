<?php
	
    $con=new mysqli("localhost","root","","angulardb");
  
    $data=file_get_contents('php://input');
    
    $dt = json_decode($data);
  
    $emp_name = $dt->emp_name;
    $emp_add  = $dt->emp_add;
    $emp_mob  =  $dt->emp_mob;

    
  $query = "insert into tblemp(emp_name,emp_add,emp_mob)values('$emp_name','$emp_add','$emp_mob')";
  $con->query($query);

   echo "success";
    
  /*   $qu = "select * from tblemp";
    
     $rows = $con->query($qu);

    while($row = $rows->fetch_assoc())
     {
        $pp[]  = $row;
        
     }
    
    echo json_encode($pp);
   */
    
?>

