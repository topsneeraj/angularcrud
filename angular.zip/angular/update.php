<?php
	
    $con=new mysqli("localhost","root","","angulardb");
  
    $data=file_get_contents('php://input');
    
    $dt = json_decode($data);
  
    $emp_name = $dt->emp_name;
    $emp_add  = $dt->emp_add;
    $emp_mob  =  $dt->emp_mob;
    $emp_id = $dt->emp_id;

    
  $query = "update tblemp set emp_name='$emp_name',emp_add='$emp_add',emp_mob='$emp_mob',emp_mob='$emp_mob' where emp_id='$emp_id'";
  $con->query($query);

  $query1 = "select * from tblemp"; //where sid='$sid'";
    
  $rows1 = $con->query($query1);
  
  while ($row = $rows1->fetch_assoc()) {
      
      $pp[] = $row;
  }
  
  echo json_encode($pp);
    
  /*   $qu = "select * from tblemp";
    
     $rows = $con->query($qu);

    while($row = $rows->fetch_assoc())
     {
        $pp[]  = $row;
        
     }
    
    echo json_encode($pp);
   */
    
?>

