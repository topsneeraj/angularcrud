import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,NgForm} from '@angular/forms';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { ListdataComponent } from './listdata/listdata.component';
import{RouterModule,Routes} from '@angular/router';
import{EditlistComponent} from './editlist/editlist.component';

const app:Routes = [{path:"edit",component:EditlistComponent},{path:"listdata",component:ListdataComponent},{path:'',component:ListdataComponent}];

@NgModule({
  declarations: [
    AppComponent,
    EditlistComponent,
    ListdataComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(app)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
