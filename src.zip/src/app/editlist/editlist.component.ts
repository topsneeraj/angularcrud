import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Params} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {Tblemp} from '../tblemp';
import {Router} from '@angular/router';
@Component({
  selector: 'app-editlist',
  templateUrl: './editlist.component.html',
  styleUrls: ['./editlist.component.css']
})
export class EditlistComponent implements OnInit {

  constructor(private test:ActivatedRoute,private http:HttpClient, private route:Router) { }
  emp_id:any;
  singleemp :Tblemp[];
  finalval :Tblemp;
  ngOnInit() {

    this.emp_id =  this.test.snapshot.params['foo'];

        this.http.get("http://localhost/angular/selectbyid.php?emp_id="+this.emp_id).subscribe(resp=>{


        this.singleemp = <Tblemp[]>resp;
        this.finalval = this.singleemp[0];


        })



  }

  addstudent(fromval)
  {
   var emp_name1 = fromval.value.empname;
   var emp_add1 = fromval.value.empadd;
   var emp_mob1 = fromval.value.empmob;
   var emp_id1 = fromval.value.empid;

   alert(emp_name1)
   var obj = {"emp_name":emp_name1,"emp_add":emp_add1,"emp_mob":emp_mob1,"emp_id":emp_id1};


      this.http.post("http://localhost/angular/update.php",obj).subscribe(res=>{

       alert("delete");
       
          this.route.navigate(['/listdata']);

         

      })

  }

}
