import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Tblemp} from '../tblemp'
import{Router} from '@angular/router';

@Component({
  selector: 'app-listdata',
  templateUrl: './listdata.component.html',
  styleUrls: ['./listdata.component.css']
})
export class ListdataComponent implements OnInit {

  tbllist = new Array<Tblemp>();
  constructor(private http:HttpClient, private rout :Router) { }

  ngOnInit() {

    this.getdata();

  }

  getdata()
  {
     this.http.get("http://localhost/angular/select.php").subscribe(resep=>{

      
         this.tbllist = <Tblemp[]>resep

     })

  }
  deleterecord(id)
  {

    alert(id);

    this.http.get("http://localhost/angular/delete.php?emp_id="+id).subscribe(resep=>{

      this.rout.navigate(['/listdata']);

  })


  }
}
